# ESC 3 kW — güncel A2 paketi

- **KiCad:** `hardware_a2/ESC_3kW_A2.kicad_pro`
- **PDF şemalar:** `ESC_3kW_A2_semalar.pdf`
- **Tarayıcıda inceleme:** `hardware_a2/inceleme.html`
- **Tasarım açıklamaları:** `hardware_a2/README.md`
- **Açık işler ve kabul kriterleri:** `hardware_a2/release_register.json`
- **Kontrol sonuçları:** `verification/a2_checks.json`

Güncel revizyon A2'dir. `hardware` klasörü A1 referansını ve A2 jeneratörünün okuduğu elektriksel kaynak tanımını içerir; bağımlılık nedeniyle pakette tutulmuştur.

A2 bir mühendislik inceleme revizyonudur. Üretim BOM'u, PCB, firmware ve fiziksel güç doğrulaması tamamlanmamıştır. Web stok kayıtları sipariş veya rezervasyon anlamına gelmez.
